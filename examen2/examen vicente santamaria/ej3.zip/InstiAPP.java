//Vicente Santamaria Botella

public class InstiAPP 
{
    public static void main(String[] args) 
    {   
        Estudiante paco = new Estudiante("Paco","Sanchez","49761469A",1999,6.9);
        paco.Imprimeinfo();       
    }
}
