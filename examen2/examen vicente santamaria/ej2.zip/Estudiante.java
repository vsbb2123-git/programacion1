//Vicente Santamaria Botella
public class Estudiante
{
    //creamos los atributos 
    private String Nombre, Apellidos, DNI;
    private int AnyoNacimiento; 
    private double NotaMedia; 
    //Constructor   
    public Estudiante(String Nombre, String Apellidos, String DNI, int AnyoNacimiento, double NotaMedia)
    {
        this.Nombre=Nombre;
        this.Apellidos=Apellidos;
        this.DNI=DNI;
        if(NotaMedia<=10 && NotaMedia>=0)
        {
            this.NotaMedia=NotaMedia;
        }
        else
        {
            System.out.println("Nota media inválida, tiene que ser un numero entre 0 y 10");
        }
        if(AnyoNacimiento<=2009 && AnyoNacimiento>=1900)
        {
            this.AnyoNacimiento=AnyoNacimiento;
        }
        else
        {
            System.out.println("Año de nacimiento inválido, tiene que ser una fecha entre 1900 y 2009");
        }
    }
    //Getters y setters
    public String getNombre() 
    {
        return Nombre;
    }
    public void setNombre(String nombre) 
    {
        Nombre = nombre;
    }
    public String getApellidos() 
    {
        return Apellidos;
    }
    public void setApellidos(String apellidos) 
    {
        Apellidos = apellidos;
    }
    public String getDNI() 
    {
        return DNI;
    }
    public void setDNI(String dNI) 
    {
        DNI = dNI;
    }
    public int getAnyoNacimiento() 
    {
        return AnyoNacimiento;
    }
    public void setAnyoNacimiento(int anyoNacimiento) 
    {
        if(AnyoNacimiento<=2009 && AnyoNacimiento>=1900)
        {
            AnyoNacimiento = anyoNacimiento;
        }
        else
        {
            System.out.println("Año de nacimiento inválido, tiene que ser una fecha entre 1900 y 2009");
        }
    }
    public double getNotaMedia() 
    {
        return NotaMedia;
    }
    public void setNotaMedia(double notaMedia) 
    {
        if(notaMedia<=10 &&  notaMedia>=0)
        {
            NotaMedia=notaMedia;
        }
        else
        {
            System.out.println("Nota media inválida, tiene que ser un numero entre 0 y 10");
        }
    }
    //Métodos
    public void Imprimeinfo()
    {
        System.out.println("Alumno/a: "+Nombre+" "+Apellidos);
        System.out.println("DNI: "+DNI);
        System.out.println("Edad: "+ (2023-AnyoNacimiento));
        System.out.println("Nota media: "+ NotaMedia);
    }
}